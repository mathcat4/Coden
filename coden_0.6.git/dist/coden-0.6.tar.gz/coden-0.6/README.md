# This is a project based on codes, secret codes...


### Example:

```python
>>>import coden
>>>en = coden.secret("Hello PyPI", mode = "encode")
>>>print(en)
j@nnq rar)
>>>de =  coden.secret("j@nnq rar)", mode = "decode")
>>>print(de)
hello pypi

```

### Way to install:

```bash
$ pip install coden
```

### Requirements

- [Python 3](https://www.python.org/download/releases/3.0/ "Download Python 3 releases")

### [Home Page](https://github.com/Tams-Tams/Codes/tree/master/coden_0.6.git)



Thank you,
Tanmay