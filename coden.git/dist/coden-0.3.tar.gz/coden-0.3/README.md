This is a project based on codes, secret codes...


Example:

```
>>>import coden
>>>en = coden.secret("Hello PyPI", mode = "encode")
>>>print(en)
j@nnq rar)
>>>de =  coden.secret("j@nnq rar)", mode = "decode")
>>>print(de)
hello pypi

```

Way to install:

```
pip install coden
```

Thank you,
Tanmay